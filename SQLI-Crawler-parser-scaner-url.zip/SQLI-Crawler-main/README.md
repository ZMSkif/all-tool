<p align='center'>
  <b>Follow me here:</b><br>  
  <a href="https://discord.gg/gzEvEC4wXh">Discord</a> |
  <a href="https://www.youtube.com/channel/UC-XII5SSqbMOF1UX3N0Gl8g">YouTube</a> |
  <a href="https://github.com/KanekiX2">Github</a> |
  <a href="https://twitter.com/Kaneki_Web">Twitter</a>
</p>

---

**FR:** A but educatif seulement.  
**EN:** For educational purposes only.  

<br><br>

## 🛠️ Download
```bash
git clone https://github.com/KanekiX2/SQLI-Crawler.git
cd SQLI-Crawler
pip install -r requirements.txt
```



## 🔨 Usage
```bash
usage: Crawler.py [-h] -d DORKS [-s SCAN] [-e ENGINE]

optional arguments:
  -h, --help            show this help message and exit
  -d DORKS, --dorks DORKS
                        Your dorks list
  -s SCAN, --scan SCAN  Enable scanner ex: -s true/false
  -e ENGINE, --engine ENGINE
                        Search engine ex: google, yahoo, bing...
```



## 📸 Demo  
![Demo Image](https://github.com/KanekiX2/SQLI-Crawler/blob/main/issets/demo.gif?raw=true)


## 📄 Contact
Discord Server: [Click Here](https://discord.gg/bdUM6SbEpJ)  
Discord Username: `Kaneki SΛD#8888`  
Conatct Email: `kaneki_pro@protonmail.com`  
